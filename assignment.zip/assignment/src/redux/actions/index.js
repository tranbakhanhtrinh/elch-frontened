import { productSlice } from "../slices/productSlice";

export const {setProducts, deleteProduct} = productSlice.actions;